﻿#include "Character.h"
#include "File.h"
#include "Game.h"
#include "Menu.h"

using namespace std;

void main() {
	setlocale(LC_ALL, "Ukrainian");
	
	int so, x;
	Game game;
	Menu menu;
	so = menu.startMenu();
	auto mag = new Magician(file->Load());
	if (mag && so == 2) {
		Game game(mag);
	}
	
	switch (so)
	{
	case 1:
		x = menu.educationOrBegin();
		if (x == 1) {
			game.educationPart1();
			game.battle(4, 1000, 500);
			game.educationPart2();
			game.mainMenu();
		}
		else {
			game.mainMenu();
		}
		break;
	case 2:
		game.mainMenu();
		break;
	case 3:
		break;
	}
}


/*int main()
{
    auto mag = new Magician(3, 3, 3, 3, 3);

    auto fire = mag->UseFireMagic();
    std::cout << mag << std::endl;
    auto* file = new File<Magician>("", "data.bin");
    //cout << "Save = " << file->Save(*mag) << endl;
    cout << "Load = ";
    mag = new Magician(file->Load());
    std::cout << mag << std::endl;
    return 0;
}

*/