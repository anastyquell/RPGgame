#pragma once

#include <iostream>
#include <Windows.h>
using namespace std;